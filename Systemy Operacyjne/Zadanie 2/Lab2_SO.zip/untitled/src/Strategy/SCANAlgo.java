package Strategy;

import Request.Request;
import Sort.SortByPosition;

import java.util.List;

public class SCANAlgo extends Strategy {
    private int driveSize;

    public SCANAlgo(List<Request> generatedRequests, List<Request> activeRequests, List<Request> finishedRequests, int driveSize){
        this.generatedRequests = createNewList(generatedRequests);
        this.activeRequests = createNewList(activeRequests);
        this.finishedRequests = createNewList(finishedRequests);
        this.driveSize = driveSize;
    }

    @Override
    public void requestStrategy() {
        int currentTime = 0;
        int readerCounter = 0;
        int currentIndex = 0;
        int i = 0;
        boolean backwards = false;

        generatedRequests.sort(new SortByPosition());

        while(!generatedRequests.isEmpty()){

            if(!backwards){
                if(currentIndex==generatedRequests.get(i).getPosition()){
                    i++;
                    if(generatedRequests.get(i-1).getArrivalTime()<=currentTime){
                        addToFinishedFromGenerated(generatedRequests.get(i-1), currentTime);
                        i--;
                    }
                }

                else if(currentIndex!=generatedRequests.get(i).getPosition()){
                    currentTime++;
                    currentIndex++;
                    readerCounter++;
                }

                if(currentIndex==driveSize && !generatedRequests.isEmpty()){
                    backwards = true;
                    i = generatedRequests.size()-1;
                }

                if(i==generatedRequests.size()) i--;
            }

            else{
                if(currentIndex==generatedRequests.get(i).getPosition()){
                    if(generatedRequests.get(i).getArrivalTime()<=currentTime){
                        addToFinishedFromGenerated(generatedRequests.get(i), currentTime);
                    }
                    if(i>0) i--;
                }

                else if(currentIndex!=generatedRequests.get(i).getPosition()){
                    currentTime++;
                    currentIndex--;
                    readerCounter++;
                }

                if(currentIndex==0){
                    backwards = false;
                }
            }
        }
        calculateData(currentTime, readerCounter);
    }
}

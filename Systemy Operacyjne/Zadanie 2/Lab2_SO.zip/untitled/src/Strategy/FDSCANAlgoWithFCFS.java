package Strategy;

import Request.*;

import java.util.List;

public class FDSCANAlgoWithFCFS extends RealTimeStrategy {
    public FDSCANAlgoWithFCFS(List<Request> generatedRequests, List<Request> activeRequests, List<Request> finishedRequests, List<Request> generatedRTRequests, List<Request> activeRTRequests, List<Request> finishedRTRequests){
        this.generatedRequests = createNewList(generatedRequests);
        this.activeRequests = createNewList(activeRequests);
        this.finishedRequests = createNewList(finishedRequests);
        this.generatedRTRequests = createNewRTList(generatedRTRequests);
        this.activeRTRequests = createNewRTList(activeRTRequests);
        this.finishedRTRequests = createNewRTList(finishedRTRequests);
    }

    @Override
    public void requestStrategy() {
        int failedCounter = 0;
        int currentTime = 0;
        int currentPosition = 0;
        int readerCounter = 0;

        addToActive(currentTime);
        addToActiveRT(currentTime);

        while(!(generatedRequests.isEmpty() && activeRequests.isEmpty() && generatedRTRequests.isEmpty() && activeRTRequests.isEmpty())){
            // standard algo part
            if(activeRTRequests.isEmpty()){
                if(!activeRequests.isEmpty()){

                    if(activeRequests.get(0).getPosition()>currentPosition) currentPosition++;

                    else if(activeRequests.get(0).getPosition()<currentPosition) currentPosition--;

                    currentTime++;
                    readerCounter++;
                    if(activeRequests.get(0).getPosition()==currentPosition){
                        addToFinished(activeRequests.get(0), currentTime);
                    }

                    addToActive(currentTime);
                    addToActiveRT(currentTime);
                }

                else{
                    currentTime++;
                    addToActive(currentTime);
                    addToActiveRT(currentTime);
                    sortByDeadline(activeRTRequests);
                }
            }
            // real time part
            // going to the fastest ending deadline but reachable
            else {

                if(((RealTimeRequest)activeRTRequests.get(0)).getDealLine()>=Math.abs(currentPosition-activeRTRequests.get(0).getPosition())){
                    currentTime = currentTime + Math.abs(currentPosition-activeRTRequests.get(0).getPosition());
                    readerCounter = readerCounter + Math.abs(currentPosition-activeRTRequests.get(0).getPosition());

                    for(int i=0; i<activeRTRequests.size(); i++){
                        ((RealTimeRequest) activeRTRequests.get(i)).setDeadline(((RealTimeRequest) activeRTRequests.get(i)).getDealLine()-Math.abs(currentPosition-activeRTRequests.get(0).getPosition()));
                        if(((RealTimeRequest) activeRTRequests.get(i)).getDealLine()<0){
                            failedCounter++;
                            activeRTRequests.remove(activeRTRequests.get(i));
                        }
                    }

                    currentPosition = activeRequests.get(0).getPosition();
                    addToFinishedRT(activeRTRequests.get(0), currentTime);
                    addToActiveRT(currentTime);
                    sortByDeadline(activeRTRequests);
                }

                else{
                    activeRTRequests.remove(activeRTRequests.get(0));
                    failedCounter++;
                }
            }
        }
        realTimeCalculations(currentTime, readerCounter, failedCounter);
    }
}

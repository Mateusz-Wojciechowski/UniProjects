package Strategy;

import Request.Request;
import Sort.SortByPosition;

import java.util.List;

public class CSCANAlgo extends Strategy{
    private int driveSize;

    public CSCANAlgo(List<Request> generatedRequests, List<Request> activeRequests, List<Request> finishedRequests, int driveSize){
        this.generatedRequests = createNewList(generatedRequests);
        this.activeRequests = createNewList(activeRequests);
        this.finishedRequests = createNewList(finishedRequests);
        this.driveSize = driveSize;
    }

    @Override
    public void requestStrategy() {
        int currentTime = 0;
        int readerCounter = 0;
        int currentIndex = 0;
        int i = 0;

        generatedRequests.sort(new SortByPosition());

            while(!generatedRequests.isEmpty()){

                if(currentIndex==generatedRequests.get(i).getPosition()){
                    i++;
                        if(generatedRequests.get(i-1).getArrivalTime()<=currentTime){
                            addToFinishedFromGenerated(generatedRequests.get(i-1), currentTime);
                            i--;
                        }
                    }

                    else if(currentIndex!=generatedRequests.get(i).getPosition()){
                        currentTime++;
                        currentIndex++;
                        readerCounter++;
                    }

                    if(currentIndex==driveSize && !generatedRequests.isEmpty()){
                        currentIndex = 0;
                        i = 0;
                    }
                    if(i==generatedRequests.size()) i--;
                }
            calculateData(currentTime, readerCounter);
    }

}

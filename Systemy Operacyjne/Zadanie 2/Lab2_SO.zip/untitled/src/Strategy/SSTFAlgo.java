package Strategy;

import Request.Request;

import java.util.List;

public class SSTFAlgo extends Strategy {

    public SSTFAlgo(List<Request> generatedRequests, List<Request> activeRequests, List<Request> finishedRequests){
        this.generatedRequests = createNewList(generatedRequests);
        this.activeRequests = createNewList(activeRequests);
        this.finishedRequests = createNewList(finishedRequests);
    }
    @Override
    public void requestStrategy() {
        int currentTime = 0;
        int readerCounter = 0;
        int currentPosition = 0;
        addToActive(currentTime);
        sortByDistance(activeRequests);

        while(!(generatedRequests.isEmpty() && activeRequests.isEmpty())){
            if(!activeRequests.isEmpty()){
                currentTime = currentTime + Math.abs(currentPosition - activeRequests.get(0).getPosition());
                readerCounter = readerCounter + Math.abs(currentPosition - activeRequests.get(0).getPosition());
                currentPosition = activeRequests.get(0).getPosition();
                addToFinished(activeRequests.get(0), currentTime);
                addToActive(currentTime);
                sortByDistance(activeRequests);
            }

            else{
                currentTime++;
                addToActive(currentTime);
                sortByDistance(activeRequests);
            }
        }
        calculateData(currentTime, readerCounter);
    }
}

package Strategy;

import Request.RealTimeRequest;
import Request.Request;
import Sort.SortByDeadline;
import Sort.SortByWaitingTime;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public abstract class RealTimeStrategy extends Strategy{
    protected List<Request> generatedRTRequests;
    protected List<Request> activeRTRequests;
    protected List<Request> finishedRTRequests;

    public static List<Request> generateRTRequests(int amount, int arrivalOrigin, int arrivalTimeBound, int positionOrigin, int positionBound, int deadlineOrigin, int deadlineBound){
        List<Request> requestList = new ArrayList<>();
        Random generator = new Random();
        for(int i=0; i<amount; i++){
            requestList.add(new RealTimeRequest((int) generator.nextInt(arrivalOrigin, arrivalTimeBound), (int) generator.nextInt(positionOrigin, positionBound), generator.nextInt(deadlineOrigin, deadlineBound)));
        }

        return requestList;
    }

    public List<Request> createNewRTList(List<Request> generatedRTRequests){
        List<Request> requestList = new ArrayList<>();

        for(Request request: generatedRTRequests){
            requestList.add(new RealTimeRequest(request.getArrivalTime(), request.getPosition(), ((RealTimeRequest) request).getDealLine()));
        }
        return requestList;
    }
    public void addToActiveRT(int currentTime){
        for(int i=0; i<generatedRTRequests.size(); i++){
            if(generatedRTRequests.get(i).getArrivalTime()<=currentTime){
                activeRTRequests.add(generatedRTRequests.get(i));
                generatedRTRequests.remove(generatedRTRequests.get(i));
            }
        }
    }

    public void addToFinishedRT(Request realTimeRequest, int currentTime){
        finishedRTRequests.add(realTimeRequest);
        realTimeRequest.setDoneTime(currentTime);
        realTimeRequest.setWaitingTime(realTimeRequest.getDoneTime()-realTimeRequest.getArrivalTime());
        activeRTRequests.remove(realTimeRequest);
    }

    public void sortByDeadline(List<Request> requestList){
        requestList.sort(new SortByDeadline());
    }

    public void realTimeCalculations(int currentTime, int readerCounter, int failedCounter){
        float averageWaitingTime = 0;
        float longestWaitingTime = 0;
        float averageWaitingTimeRT = 0;
        float longestWaitingTimeRT = 0;

        averageWaitingTime = findAverageTime(finishedRequests);
        averageWaitingTimeRT = findAverageTime(finishedRTRequests);

        Collections.sort(finishedRequests, new SortByWaitingTime());
        longestWaitingTime = finishedRequests.get(finishedRequests.size()-1).getWaitingTime();

        Collections.sort(finishedRTRequests, new SortByWaitingTime());
        if(!finishedRTRequests.isEmpty()) longestWaitingTimeRT = finishedRTRequests.get(finishedRTRequests.size()-1).getWaitingTime();

        System.out.println("All requests took: " + currentTime);
        System.out.println("Average waiting time was: " + averageWaitingTime);
        System.out.println("Longest waiting time was: " + longestWaitingTime);
        System.out.println("Average waiting time (real time) was: " + averageWaitingTimeRT);
        System.out.println("Longest waiting time (real time) was: " + longestWaitingTimeRT);
        System.out.println("Finished realtime requests: " + finishedRTRequests.size());
        System.out.println("Failed real time requests: " + failedCounter);
        System.out.println("The reader moved " + readerCounter + " times");
    }

    public List<Request> getGeneratedRTRequests() {
        return generatedRTRequests;
    }

    public void setGeneratedRTRequests(List<Request> generatedRTRequests) {
        this.generatedRTRequests = generatedRTRequests;
    }

    public List<Request> getActiveRTRequests() {
        return activeRTRequests;
    }

    public void setActiveRTRequests(List<Request> activeRTRequests) {
        this.activeRTRequests = activeRTRequests;
    }

    public List<Request> getFinishedRTRequests() {
        return finishedRTRequests;
    }

    public void setFinishedRTRequests(List<Request> finishedRTRequests) {
        this.finishedRTRequests = finishedRTRequests;
    }
}

package Strategy;

import Request.*;

import java.util.Collections;
import java.util.List;

public class EDFAlgoWithFCFS extends RealTimeStrategy{

    public EDFAlgoWithFCFS(List<Request> generatedRequests, List<Request> activeRequests, List<Request> finishedRequests, List<Request> generatedRTRequests, List<Request> activeRTRequests, List<Request> finishedRTRequests){
        this.generatedRequests = createNewList(generatedRequests);
        this.activeRequests = createNewList(activeRequests);
        this.finishedRequests = createNewList(finishedRequests);
        this.generatedRTRequests = createNewRTList(generatedRTRequests);
        this.activeRTRequests = createNewRTList(activeRTRequests);
        this.finishedRTRequests = createNewRTList(finishedRTRequests);
    }


    @Override
    public void requestStrategy() {
        int failedCounter = 0;
        int currentTime = 0;
        int currentPosition = 0;
        int readerCounter = 0;

        addToActive(currentTime);
        addToActiveRT(currentTime);

        while(!(generatedRequests.isEmpty() && activeRequests.isEmpty() && generatedRTRequests.isEmpty() && activeRTRequests.isEmpty())){
            // standard algo part
            if(activeRTRequests.isEmpty()){
                if(!activeRequests.isEmpty()){

                    if(activeRequests.get(0).getPosition()>currentPosition) currentPosition++;

                    else if(activeRequests.get(0).getPosition()<currentPosition) currentPosition--;

                    currentTime++;
                    readerCounter++;
                    if(activeRequests.get(0).getPosition()==currentPosition){
                        addToFinished(activeRequests.get(0), currentTime);
                    }

                    addToActive(currentTime);
                    addToActiveRT(currentTime);
                }

                else{
                    currentTime++;
                    addToActive(currentTime);
                    addToActiveRT(currentTime);
                    sortByDeadline(activeRTRequests);
                }
            }
            // real time part
            else {
                if(activeRTRequests.get(0).getPosition()>currentPosition) currentPosition++;

                else if(activeRTRequests.get(0).getPosition()<currentPosition) currentPosition--;

                currentTime++;
                readerCounter++;

                if(activeRTRequests.get(0) instanceof RealTimeRequest){

                    addToActive(currentTime);
                    addToActiveRT(currentTime);

                    for(int i=0; i<activeRTRequests.size(); i++){
                        ((RealTimeRequest) activeRTRequests.get(i)).setDeadline(((RealTimeRequest) activeRTRequests.get(i)).getDealLine()-1);
                        if(((RealTimeRequest) activeRTRequests.get(i)).getDealLine()<0){
                            failedCounter++;
                            activeRTRequests.remove(activeRTRequests.get(i));
                        }
                    }

                    if(!activeRTRequests.isEmpty() && ((RealTimeRequest) activeRTRequests.get(0)).getDealLine()<0){
                        failedCounter++;
                        activeRTRequests.remove(activeRTRequests.get(0));
                    }

                    else{
                        if(!activeRTRequests.isEmpty() && activeRTRequests.get(0).getPosition()==currentPosition){
                            addToFinishedRT(activeRTRequests.get(0), currentTime);
                            sortByDeadline(activeRTRequests);
                        }
                    }
                }
             }
            }
            realTimeCalculations(currentTime, readerCounter, failedCounter);
          }
}

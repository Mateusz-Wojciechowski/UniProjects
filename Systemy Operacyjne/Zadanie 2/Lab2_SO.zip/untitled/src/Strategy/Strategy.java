package Strategy;

import Request.Request;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import Request.*;
import Sort.SortByDistance;
import Sort.SortByPosition;
import Sort.SortByWaitingTime;

public abstract class Strategy {
    protected List<Request> generatedRequests;
    protected List<Request> activeRequests;
    protected List<Request> finishedRequests;

    public abstract void requestStrategy();

    // list management methods
    public static List<Request> generateRequests(int amount, int arrivalOrigin, int arrivalTimeBound, int positionOrigin, int positionBound){
        List<Request> requestList = new ArrayList<>();
        Random generator = new Random();
        for(int i=0; i<amount; i++){
            requestList.add(new Request((int) generator.nextInt(arrivalOrigin, arrivalTimeBound), (int) generator.nextInt(positionOrigin, positionBound)));
        }

        return requestList;
    }
    public void addToActive(int currentTime){
        for(int i=0; i<generatedRequests.size(); i++){
            if(generatedRequests.get(i).getArrivalTime()<=currentTime){
                activeRequests.add(generatedRequests.get(i));
                generatedRequests.remove(generatedRequests.get(i));
            }
        }
    }

    public void addToFinished(Request finishedRequest, int currentTime){
        finishedRequests.add(finishedRequest);
        finishedRequest.setDoneTime(currentTime);
        finishedRequest.setWaitingTime(finishedRequest.getDoneTime()-finishedRequest.getArrivalTime());
        activeRequests.remove(finishedRequest);
    }

    public void addToFinishedFromGenerated(Request finishedRequest, int currentTime){
        finishedRequests.add(finishedRequest);
        finishedRequest.setDoneTime(currentTime);
        finishedRequest.setWaitingTime(finishedRequest.getDoneTime()-finishedRequest.getArrivalTime());
        generatedRequests.remove(finishedRequest);
    }

    public List<Request> createNewList(List<Request> generatedRequests){
        List<Request> requestList = new ArrayList<>();

        for(Request request: generatedRequests){
            requestList.add(new Request(request.getArrivalTime(), request.getPosition()));
        }
        return requestList;
    }

    // sorting methods

    public void sortByDistance(List<Request> requestList){
        requestList.sort(new SortByDistance());
    }

    public void sortByPosition(List<Request> requestList){
        requestList.sort(new SortByPosition());
    }

    // calculations methods

    public float findAverageTime(List<Request> finishedRequests){
        float averageTime = 0;
        for(Request request: finishedRequests){
            averageTime = averageTime + request.getWaitingTime();
        }
        averageTime = averageTime/finishedRequests.size();
        return averageTime;
    }

    // search methods
    public void searchForPosition(int position, int currentTime){
        for(int i=0; i<activeRequests.size(); i++){
            if(position==activeRequests.get(i).getPosition()){
                addToFinished(activeRequests.get(i), currentTime);
            }
        }
    }

    public void calculateData(int currentTime, int readerCounter){
        float averageWaitingTime = 0;
        float longestWaitingTime = 0;

        averageWaitingTime = findAverageTime(finishedRequests);

        Collections.sort(finishedRequests, new SortByWaitingTime());
        longestWaitingTime = finishedRequests.get(finishedRequests.size()-1).getWaitingTime();

        System.out.println("All requests took: " + currentTime);
        System.out.println("Average waiting time was: " + averageWaitingTime);
        System.out.println("Longest waiting time was: " + longestWaitingTime);
        System.out.println("The reader moved " + readerCounter + " times");
    }
    public List<Request> getGeneratedRequests() {
        return generatedRequests;
    }

    public void setGeneratedRequests(List<Request> generatedRequests) {
        this.generatedRequests = generatedRequests;
    }

    public List<Request> getActiveRequests() {
        return activeRequests;
    }

    public void setActiveRequests(List<Request> activeRequests) {
        this.activeRequests = activeRequests;
    }

    public List<Request> getFinishedRequests() {
        return finishedRequests;
    }

    public void setFinishedRequests(List<Request> finishedRequests) {
        this.finishedRequests = finishedRequests;
    }
}

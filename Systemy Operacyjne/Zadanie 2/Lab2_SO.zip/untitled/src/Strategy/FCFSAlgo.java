package Strategy;

import Request.Request;
import Strategy.Strategy;



import java.util.List;

public class FCFSAlgo extends Strategy {

    public FCFSAlgo(List<Request> generatedRequests, List<Request> activeRequests, List<Request> finishedRequests){
        this.generatedRequests = createNewList(generatedRequests);
        this.activeRequests = createNewList(activeRequests);
        this.finishedRequests = createNewList(finishedRequests);
    }
    @Override
    public void requestStrategy() {
        int currentTime = 0;
        int currentPosition = 0;
        int readerCounter = 0;

        addToActive(currentTime);

        while(!(generatedRequests.isEmpty() && activeRequests.isEmpty())){
            if(!activeRequests.isEmpty()){
                currentTime = currentTime + Math.abs(currentPosition - activeRequests.get(0).getPosition());
                readerCounter = readerCounter + Math.abs(currentPosition - activeRequests.get(0).getPosition());
                currentPosition = activeRequests.get(0).getPosition();
                addToFinished(activeRequests.get(0), currentTime);
                addToActive(currentTime);
            }

             else{
                currentTime++;
                addToActive(currentTime);
             }
            }

            calculateData(currentTime, readerCounter);
        }

}

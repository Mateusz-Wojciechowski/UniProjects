package Request;

import Request.Request;

public class RealTimeRequest extends Request {
    int deadline;
    public RealTimeRequest(int arrivalTime, int position, int deadLine) {
        super(arrivalTime, position);
        this.deadline = deadLine;
    }

    public int getDealLine() {
        return deadline;
    }

    public void setDeadline(int deadLine) {
        this.deadline = deadLine;
    }
}

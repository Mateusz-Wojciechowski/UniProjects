package Sort;

import Request.Request;

import java.util.Comparator;

public class SortByWaitingTime implements Comparator<Request> {
    @Override
    public int compare(Request o1, Request o2) {
        if(o1.getWaitingTime() == o2.getWaitingTime()) return 0;
        return (int) (o1.getWaitingTime() - o2.getWaitingTime());
    }
}

package Sort;

import Request.Request;

import java.util.Comparator;

public class SortByDistance implements Comparator<Request>{
    int currentPosition;
    @Override
    public int compare(Request o1, Request o2) {
        if(Math.abs(o1.getPosition()-currentPosition)==Math.abs(o2.getPosition()-currentPosition)) return 0;
        return (int) (Math.abs(o1.getPosition()-currentPosition) - Math.abs(o2.getPosition()-currentPosition));
    }
}

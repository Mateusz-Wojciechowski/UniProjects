package Sort;

import Request.RealTimeRequest;
import Request.Request;

import java.lang.invoke.WrongMethodTypeException;
import java.util.Comparator;

public class SortByDeadline implements Comparator<Request> {
    @Override
    public int compare(Request o1, Request o2) {
        if(o1 instanceof RealTimeRequest && o2 instanceof RealTimeRequest){
            if(((RealTimeRequest) o1).getDealLine() == ((RealTimeRequest) o2).getDealLine()) return 0;
            return (int) (((RealTimeRequest) o1).getDealLine() - ((RealTimeRequest) o2).getDealLine());
        }
        else throw new WrongMethodTypeException("Comparator Not Suitable for this type");
    }
}

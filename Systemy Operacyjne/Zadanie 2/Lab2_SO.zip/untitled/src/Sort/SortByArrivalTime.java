package Sort;

import Request.Request;

import java.util.Comparator;

public class SortByArrivalTime implements Comparator<Request>{
    @Override
    public int compare(Request o1, Request o2) {
        if(o1.getArrivalTime() == o2.getArrivalTime()) return 0;
        return (int) (o1.getArrivalTime() - o2.getArrivalTime());
    }
}

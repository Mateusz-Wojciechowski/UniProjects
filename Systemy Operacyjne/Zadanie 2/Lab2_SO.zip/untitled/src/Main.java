import Request.Request;
import Strategy.Strategy;
import Strategy.*;

import java.util.ArrayList;
import java.util.List;

// metody takie jak add remove moga zostac ujednolicone dla zwyklych requestow i realTime, bo oba sa typu Request

public class Main {
    public static void main(String[] args) {
        List<Request> generatedRequests = new ArrayList<>();
        List<Request> activeRequests = new ArrayList<>();
        List<Request> finishedRequests = new ArrayList<>();
        List<Request> generatedRTRequests = new ArrayList<>();
        List<Request> activeRTRequests = new ArrayList<>();
        List<Request> finishedRTRequests = new ArrayList<>();

//        generatedRequests.add(new Request(1, 3));
//        generatedRequests.add(new Request(3, 5));
//        generatedRequests.add(new Request(5, 8));
//        generatedRequests.add(new Request(17, 2));
//        generatedRequests.add(new Request(12, 16));
//        generatedRequests.add(new Request(13, 11));


        generatedRequests = Strategy.generateRequests(1000, 0, 1000, 0, 1000);
        generatedRTRequests = RealTimeStrategy.generateRTRequests(100, 0, 10000, 0, 1000, 1, 1000);

        FCFSAlgo fcfsAlgo = new FCFSAlgo(generatedRequests, activeRequests, finishedRequests);
        SSTFAlgo sstfAlgo = new SSTFAlgo(generatedRequests, activeRequests, finishedRequests);
        CSCANAlgo cscanAlgo = new CSCANAlgo(generatedRequests, activeRequests, finishedRequests,1000);
        SCANAlgo scanAlgo = new SCANAlgo(generatedRequests, activeRequests, finishedRequests, 1000);
        EDFAlgoWithFCFS edfAlgoWithFCFS = new EDFAlgoWithFCFS(generatedRequests, activeRequests, finishedRequests, generatedRTRequests, activeRTRequests, finishedRTRequests);
        FDSCANAlgoWithFCFS fdscanAlgoWithFCFS = new FDSCANAlgoWithFCFS(generatedRequests, activeRequests, finishedRequests, generatedRTRequests, activeRTRequests, finishedRTRequests);

        System.out.println("FCFS Algo:");
        fcfsAlgo.requestStrategy();
        System.out.println();
        System.out.println("SSTF Algo:");
        sstfAlgo.requestStrategy();
        System.out.println();
        System.out.println("SCAN Algo"); // scan łapie nieskonczona petle przy rozciagnietym arrivalTime
        scanAlgo.requestStrategy();
        System.out.println();
        System.out.println("CSCAN Algo");
        cscanAlgo.requestStrategy();
        System.out.println();
        System.out.println("EDF Algo with FCFS");
        edfAlgoWithFCFS.requestStrategy();
        System.out.println();
        System.out.println("FDSCAN Algo with FCFS");
        fdscanAlgoWithFCFS.requestStrategy();
    }
}